from flask import Blueprint, jsonify, url_for, render_template
from flask import current_app as app
import json

bp = Blueprint('admin', __name__, url_prefix='/admin')

@bp.route('/')
def index():
    return 'admin home.'

@bp.route('/todo/')
def todo():
    return 'Parent覆盖todo11.'

@bp.route('/test')
def test():
    return render_template('test.html')
