author = 'yt'
#from .manager import create_app
from . import manager
app = manager.create_app()
